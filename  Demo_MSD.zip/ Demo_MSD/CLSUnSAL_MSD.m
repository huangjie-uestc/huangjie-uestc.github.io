function [X,res,res_d] = CLSUnSAL_MSD(M,Y,varargin)

%% [x] = clsunsal_v1(M,y,varargin)
%
%  CLSUNSAL -> collaborative sparse unmixing via variable splitting and augmented
%  Lagrangian  
%
%% --------------- Description --------------------------------------------
%
%  CLSUNSAL solves the following l2-l1 optimization  problem 
%  [size(M) = (L,p); size(X) = (p,N)]; size(Y) = (L,N)]
%
%         min  (1/2) ||M X-Y||^2_F + lambda ||X||_{2,1}
%          X              
%
%  where ||X||_{2,1} = sum(sqrt(sum(X.^2),2))
% 
%    CONSTRAINTS ACCEPTED:
%
%    1) POSITIVITY:  X >= 0;
%    2) ADDONE:  sum(X) = ones(1,N);
%
%          
%
%% -------------------- Line of Attack  -----------------------------------
%
%  CLSUNSAL solves the above optimization problem by introducing a variable
%  splitting and then solving the resulting constrained optimization with
%  the augmented Lagrangian method of multipliers (ADMM). 
% 
% 
%         min  (1/2) ||V1-Y||^2_F + lambda ||V2||_{2,1} + i_+(V3)
%          X,Z              
%         subject to: sum(X) = ones(1,N)); V1 = MX,  V2 = X;  V3 = X
%
%  Augmented Lagrangian (scaled version):
%
%       L(X,V1,V2,D1,D2,V3,D3) = (1/2) ||V1-Y||^2_F + mu/2||MX-V1-D1||^2_F
%                      + lambda ||V2||_{2,1} + mu/2||X-V2-D1||^2_F
%                      + i_+(V3) + mu/2||X-V3-D3||^2_F
%       
%  where D1, D2, and D3 are the scale Lagrange multipliers
%
%
%  ADMM:
%
%      do 
%        X  <-- arg min L(X,V1,V2,V3,D1,D2,D3)
%                    X, s.t: sum(X) = ones(1,N));
%        V1  <-- arg min L(X,V1,V2,V3,D1,D2,D3)
%                     V1
%        V2  <-- arg min L(X,V1,V2,V3,D1,D2,D3)
%                     V2
%        V2  <-- arg min L(X,V1,V2,V3,D1,D2,D3)
%                     V3
%        D1  <-- D1 - (MX-V1);
%        D2  <-- D2 - (X-V2);
%        D3  <-- D3 - (X-V3);
%
%      while ~stop_rulde
%  
% For details see
%
% M. D. Iordache, J. M. Bioucas-Dias and A. Plaza. "Collaborative Sparse 
% Regression for Hyperspectral Unmixing",  IEEE Transactions on Geoscience 
% and Remote Sensing, 2013  (accepted).
% http://dx.doi.org/10.1109/TGRS.2013.2240001 
%
%
% NOTE 1: with respect to the algorithm described in the paper, this version 
%        allows to enforce the sum-to-one constraint. 
%
%
% NOTE 2: the version clsunsal solves the same optimization problem using 
%         only two spllintings, resulting in a faster algorithm.
% ------------------------------------------------------------------------
%%  ===== Required inputs =============
%
%  M - [L(channels) x p(endmembers)] mixing matrix
%
%  y - matrix with  L(channels) x N(pixels).
%      each pixel is a linear mixture of p endmembers
%      signatures y = M*x + noise,
%
%      
%
%
%%  ====================== Optional inputs =============================
%
%  'AL_ITERS' - Minimum number of augmented Lagrangian iterations
%               Default: 100;
%               
%  lambda - regularization parameter. 
%
%
%  'POSITIVITY'  = {'yes', 'no'}; Enforces the positivity constraint: 
%                   X >= 0
%                   Default 'no'
%
%  'ADDONE'  = {'yes', 'no'}; Enforces the positivity constraint: X >= 0
%              Default 'no'
% 
%   'TOL'    - tolerance for the primal and  dual residuals 
%              Default = 1e-4; 
%
%
%  'verbose'   = {'yes', 'no'}; 
%                 'no' - work silently
%                 'yes' - display warnings
%                  Default 'no'
%        
%%  =========================== Outputs ==================================
%
% X  =  [pxN] estimated mixing matrix
%
%

%%
% ------------------------------------------------------------------
% Author: Jose Bioucas-Dias, 2012
%
%
%
%% -------------------------------------------------------------------------
%
% Copyright (July, 2012):        Jos?Bioucas-Dias (bioucas@lx.it.pt)
%
% CLSUNSAL is distributed under the terms of
% the GNU General Public License 2.0.
%
% Permission to use, copy, modify, and distribute this software for
% any purpose without fee is hereby granted, provided that this entire
% notice is included in all copies of any software which is or includes
% a copy or modification of this software and in all copies of the
% supporting documentation for such software.
% This software is being provided "as is", without any express or
% implied warranty.  In particular, the authors do not make any
% representation or warranty of any kind concerning the merchantability
% of this software or its fitness for any particular purpose."
% ---------------------------------------------------------------------



%%
%--------------------------------------------------------------
% test for number of required parametres
%--------------------------------------------------------------
% if (nargin-length(varargin)) ~= 2
%     error('Wrong number of required parameters');
% end
% mixing matrixsize
[LM,p] = size(M);
% data set size
[L,N] = size(Y);
if (LM ~= L)
    error('mixing matrix M and data set y are inconsistent');
end
% if (L<p)
%     error('Insufficient number of columns in y');
% end


%%
%--------------------------------------------------------------
% Set the defaults for the optional parameters
%--------------------------------------------------------------
% maximum number of AL iteration
AL_iters = 1000;
% regularizatio parameter
lambda = 0.0;
% display only sunsal warnings
verbose = 'off';
% Positivity constraint
positivity = 'no';
% Sum-to-one constraint
addone = 'no';
% tolerance for the primal and dual residues
Threshold = 1e-4;
% initialization
x0 = 0;

%%
%--------------------------------------------------------------
% Local variables
%--------------------------------------------------------------


%--------------------------------------------------------------
% Read the optional parameters
%--------------------------------------------------------------
if (rem(length(varargin),2)==1)
    error('Optional parameters should always go by pairs');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'TRUE_X'
                XT=varargin{i+1};
            case 'AL_ITERS'
                AL_iters = round(varargin{i+1});
                if (AL_iters <= 0 )
                       error('AL_iters must a positive integer');
                end
            case 'LAMBDA'
                lambda = varargin{i+1};
                if lambda < 0
                       error('lambda must be positive');
                end
            case 'IM_SIZE'
               im_size = varargin{i+1};
            case 'POSITIVITY'
                positivity = varargin{i+1};
            case 'ADDONE'
                addone = varargin{i+1};
            case 'TOL'
                Threshold = varargin{i+1};
            case 'VERBOSE'
                verbose = varargin{i+1};
            case 'X0'
                x0 = varargin{i+1};
                if (size(x0,1) ~= p) | (size(x0,1) ~= N)
                    error('initial X is  inconsistent with M or Y');
                end
            otherwise
                % Hmmm, something wrong with the parameter string
                error(['Unrecognized option: ''' varargin{i} '''']);
        end;
    end;
end


% compute mean norm
norm_y = sqrt(mean(mean(Y.^2)));
% rescale M and Y and lambda
M = M/norm_y;
Y = Y/norm_y;
lambda = lambda/norm_y^2;

  

%%
%---------------------------------------------
% just least squares
%---------------------------------------------
if sum(sum(lambda == 0)) &&  strcmp(positivity,'no') && strcmp(addone,'no')
    z = pinv(M)*Y;
    % primal and dual residues
    res = 0;
    res_d = 0;
    return
end
%---------------------------------------------
% least squares constrained (sum(x) = 1)
%---------------------------------------------
SMALL = 1e-12;
B = ones(1,p);
a = ones(1,N);

if  strcmp(addone,'yes') && strcmp(positivity,'no') 
    F = M'*M;
    % test if F is invertible
    if rcond(F) > SMALL
        % compute the solution explicitly
        IF = inv(F);
        z = IF*M'*Y-IF*B'*inv(B*IF*B')*(B*IF*M'*Y-a);
        % primal and dual residues
        res = 0;
        res_d = 0;
        return
    end
end


%%
%---------------------------------------------
%  Constants and initializations
%---------------------------------------------
mu_AL = 0.01;
mu = 10*mean(lambda(:)) + mu_AL;

%F = M'*M+mu*eye(p);
[UF,SF] = svd(M'*M);
sF = diag(SF);
IF = UF*diag(1./(sF+2))*UF';
%IF = inv(F);
Aux = IF*B'*inv(B*IF*B');
x_aux = Aux*a;
IF1 = (IF-Aux*B*IF);


yy = M'*Y;

%%
%---------------------------------------------
%  Initializations
%---------------------------------------------

% no intial solution supplied
if x0 == 0
    x= IF*M'*Y;
end

% auxiliary variables
v1 = M*x;
v2 = x;
v3 = x;

% scaled Lagrange Multipliers
d1  = 0*v1;
d2  = 0*v2;
d3  = 0*v3;

%%
%---------------------------------------------
%  AL iterations - main body
%---------------------------------------------
tol1 = sqrt(N)*1e-5;
i=1;
res = inf;
res_d = inf;
mu_changed = 0;
Q=[1:p];%Initialize the original index set
P1=cell(1,p);%the original index set of non-active endmember in iteration 
P2=cell(1,p);%non-active endmember index set in iteration

while (i <= AL_iters) && ((abs (res) > tol1) || (abs (res_d) > tol1)) 
    % save z to be used later
     x = IF*(M'*(v1+d1)+(v2+d2)+(v3+d3));
      M1=M;
    T=size(Q,2);%Number of remaining rows
    R=[1:T];% Initialize the index set for each iteration
    P1{i}=[];
    P2{i}=[];
    t1=1;
    T_1=[];
    T_2=[];
    for t_1=1:T
        T_1(t_1)=norm(x(t_1,:),2);%Calculate the L2-norm value of each row of the abundance matrix
    end
    [T_1,Y_1]=sort(T_1,'descend');%descend
    t_2=1;
    while(t_2<=T-1)
         T_2(t_2)=T_1(t_2)-T_1(t_2+1);%Calculate the difference
         if(T_1(t_2)<mean(T_1)&&T_2(t_2)<0.00005)% conditions
           break
         else
             t_2=t_2+1;
         end
    end
    Threshold=T_1(t_2);%Threshold
     for t=1:T
        if (norm(x(t,:),2)<Threshold)
            P1{i}(t1)=Q(t);%the original index set of non-active endmember at iteration
            P2{i}(t1)=t;%the index set of non-active endmember in iteration
            t1=t1+1;
        end
     end
    [~,id]=ismember(P1{i},Q);%the original index set of active endmember at iteration
    Q(id)=[];
    Qsize=size(Q,2);
    [~,id]=ismember(P2{i},R);%the index set of active endmember in iteration
    R(id)=[];
    x(P2{i},:)=[];%update x
    M(:,P2{i})=[];%update M
    [UF,SF] = svd(M'*M);
    sF = diag(SF);
    IF = UF*diag(1./(sF+2))*UF';
    d2(P2{i},:)=[];%update d2
    d3(P2{i},:)=[];%update d3
        v10 = v1;
        v20 = v2;
        V2=zeros(size(v20));
        v30 = v3;
        V3=zeros(size(v30));
    % minimize with respect to v1
    % min (1/2) ||V1-Y||^2_F ++ mu/2||MX-V1-D1||^2_F
    v1 = (Y+mu*(M*x-d1))/(1+mu);
    
    % minimize with respect to v2
    % min lambda ||V2||_{2,1} + mu/2||X-V2-D1||^2_F
    v2 =  vector_soft_row(x-d2,lambda/mu);
    
    % minimize wrt v3
    % min i_+(V3) + mu/2||X-V3-D3||^2_F
    v3 = x-d3;
    % teste for positivity
    if strcmp(positivity,'yes')
        v3 = max(0,v3);
    end
    V2(R,:)=v2;
    V3(R,:)=v3;
    % minimize  wrt x
    % mim 1/2||MX-V1-D1||^2_F + 1/2||X-V2-D1||^2_F) + 1/2||X-V3-D3||^2_F
    
    % Lagrange multipliers update
    d1 = d1 -(M*x-v1);
    d2 = d2 -(x-v2);
    d3 = d3 -(x-v3);

    % update mu so to keep primal and dual residuals whithin a factor of 10
        % primal residue
        res = sqrt(norm(M*x-v1,'fro')^2 + norm(x-v2,'fro')^2+ norm(x-v3,'fro')^2);
        
        % dual residue
        res_d = mu*norm(M1'*(v1-v10)+V2-v20+V3-v30,'fro');
          if  strcmp(verbose,'yes')
            fprintf(' i = %f, res = %f, res_d = %f\n',i,res,res_d)
        end
        %clres(i)=res;
         %if  strcmp(verbose,'yes')
           % fprintf(' i = %f, res_p = %f, res_d = %f\n',i,clres(i),res_d)
        %end
        % update mu
        if res > 10*res_d
            mu = mu*2;
            d1 = d1/2;
            d2 = d2/2;
            d3 = d3/2;
            mu_changed = 1;
        elseif res_d > 10*res
            mu = mu/2;
            d1 = d1*2;
            d2 = d2*2;
            d3 = d3*2;
            mu_changed = 1;
        end
        if  mu_changed
           % update IF and IF1

           IF = UF*diag(1./(sF+2))*UF';
           mu_changed = 0;
           %mu
        end
    i=i+1;
  
        
  
end
X=zeros(p,N);
X(Q,:)=x;
x(x<0)=0;
    
 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
