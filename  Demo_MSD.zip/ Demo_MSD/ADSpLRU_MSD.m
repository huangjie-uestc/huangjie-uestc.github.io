function X1 = ADSpLRU_MSD(Y, F, parameter)

lambda1 = parameter.tau;
lambda2 = parameter.gamma;
mu      = parameter.mu;
MaxIter = parameter.MaxIter;

norm_y = sqrt(mean(Y(:).^2));
Y = Y./norm_y;
F = F./norm_y;
epsilon = 1e-5;
[L, K] = size(Y);
m = size(F, 2);

Finv = (F'*F +  3*eye(m))^-1;
W = Finv*F'*Y;

%Initialization of auxiliary matrices V1,V2,V3,V4
V1 = F*W; 
V2 = W;
V3 = W;
V4 = W;

%Initialization of Lagranfe Multipliers
D1 = V1*0;
D2 = V2*0;
D3 = V3*0;
D4 = V4*0;

%current iteration number
i = 1;

%primal residual 
res_p = inf;

%dual residual
res_d = inf;

%error tolerance
Threshold = sqrt((3*m + L)/2*K/2)*epsilon;
Q = [1:m]; %Initialize the original index set
P1 = cell(1,m);%the original index set of non-active endmember in iteration 
P2 = cell(1,m);%non-active endmember index set in iteration

%---------------------------------------------
%  ADMM iterations
%---------------------------------------------
while (i <= MaxIter) && ((abs(res_p) > Threshold) || (abs(res_d) > Threshold))
        V10 = V1;
        V20 = V2;
        V30 = V3;
        V40 = V4;
        v2=zeros(size(V20));
        v3=zeros(size(V30));
        v4=zeros(size(V40));
    W = Finv*(F'*(V1 + D1) + (V2 + D2) + (V3 + D3) + (V4 + D4));
    T=size(Q,2);%Number of remaining rows
    R=[1:T];% Initialize the index set for each iteration
    P1{i}=[];
    P2{i}=[];
    t1=1;
    T_1=[];
    T_2=[];
    for t_1=1:T
        T_1(t_1)=norm(W(t_1,:),2);%Calculate the L2-norm value of each row of the abundance matrix
    end
    [T_1,Y_1]=sort(T_1,'descend');%descend
    t_2=1;
    while(t_2<=T-1)
         T_2(t_2)=T_1(t_2)-T_1(t_2+1);%Calculate the difference
              if(T_1(t_2)<mean(T_1)&&T_2(t_2)<0.0005)% conditions
             break;
         else
             t_2=t_2+1;
         end
    end
    Threshold=T_1(t_2);%Threshold
     for t=1:T
        if (norm(W(t,:),2)<Threshold)
            P1{i}(t1)=Q(t);%the original index set of non-active endmember at iteration
            P2{i}(t1)=t;%the index set of non-active endmember in iteration
            t1=t1+1;
        end
     end
    [~,id]=ismember(P1{i},Q);%the original index set of active endmember at iteration
    Q(id)=[];
    Qsize=size(Q,2);
    [~,id]=ismember(P2{i},R);%the index set of active endmember in iteration
    R(id)=[];
    W(P2{i},:)=[];%update W
    D2(P2{i},:)=[];%update D2
    D3(P2{i},:)=[];%update D3
    D4(P2{i},:)=[];%update D4
    F(:,P2{i})=[];%update F
    Finv = (F'*F +  3*eye(Qsize))^-1;%update Finv
    %V1
    V1 = 1/(1+mu)*(Y + mu*(F*W - D1));
    %V2
    [u s v] = svd(W - D2,'econ');
    ds = diag(s);
    V2 = u*diag(max(abs(ds) - (lambda1/mu)*(1./(abs(ds)+ eps)),zeros(size(ds))))*v';
    %V3
    V3 = sign(W-D3).*max( abs(W-D3) - ...
                     ((lambda2/mu) *(1./(abs( W-D3) + eps))),0);
    %V4
    V4 = max(W - D4, 0);
    v2(R,:)=V2;
    v3(R,:)=V3;
    v4(R,:)=V4;
    %update D
    D1 = D1 - F*W + V1;
    D2 = D2 - W + V2;
    D3 = D3 - W + V3;
    D4 = D4 - W + V4;
        %primal residual
        res_p = norm([V1; V2; V3; V4] - [F*W; W; W; W], 'fro');
        %dual residual
        res_d = norm([V1; v2; v3; v4] - [V10; V20; V30; V40], 'fro');
        
     
        if res_p > 10*res_d
            mu = mu*2;
            D1 = D1/2;
            D2 = D2/2;
            D3 = D3/2;
            D4 = D4/2;
        elseif res_d > 10*res_p
            mu = mu/2;
            D1 = D1*2;
            D2 = D2*2;
            D3 = D3*2;
            D4 = D4*2;
        end
   % error(i) = norm(W - Wtrue,'fro');
    i = i + 1;
end

X1=zeros(m,K);
X = W.*(W>=0);
X1(Q,:)=X;

end
