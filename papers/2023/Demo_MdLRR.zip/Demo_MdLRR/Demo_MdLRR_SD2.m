%% demo MdLRR---for Synthetic 2 with SNR = 20 dB
%% load data
clear;clc;
addpath(genpath(pwd))
load SD2_SNR20.mat
SNR_est = 10*log10(sum(sum((F*X_true).^2))/sum(sum((Y-F*X_true).^2)));
supp = find(sum(X_true,2));

%% parameter setting for MdLRR and BiJSpLRU
% partition strategy for XT
blocknum = 3;
numpat   = blocknum *ones(1, fix(size(Y,2)/blocknum));
numpat(end) = numpat(end) + mod(size(Y,2),blocknum);
if sum(numpat)~= size(Y,2)
    error('block partition does not match!')
end

K0      = length(numpat);  % number of blocks
maxiter = 300;
parameter.verbose = 0;
parameter.K0      = K0;
parameter.MaxIter = maxiter;
parameter.numpat  = numpat;

%% run MdLRR with optimal parameters
parameter_mdlrr        = parameter;
parameter_mdlrr.gamma  = 0.0100;
parameter_mdlrr.tau    = 1;
parameter_mdlrr.mu     = 1;
tic
X_mdlrr   = MdLRR(Y,F,parameter_mdlrr);
cpu_mdlrr = toc;

SRE_mdlrr  = 10*log10( sum(X_true(:).^2) / sum( (X_true(:) - X_mdlrr(:)).^2 ) );
RMSE_mdlrr = sqrt(mean((X_mdlrr(:) - X_true(:)).^2));

%% run BiJSpLRU with optimal parameters
parameter_bijsp        = parameter;
parameter_bijsp.gamma  = 0.0100;
parameter_bijsp.tau    = 5;
parameter_bijsp.mu     = 1;

tic
X_bijsp   = BiJSpLRU(Y,F,parameter_bijsp);
cpu_bijsp = toc;

SRE_bijsp  = 10*log10( sum(X_true(:).^2) / sum( (X_true(:) - X_bijsp(:)).^2 ) );
RMSE_bijsp = sqrt(mean((X_bijsp(:) - X_true(:)).^2));

%% display SRE and RMSE values
clc
disp(['       ', 'MdLRR  ', ' BiJSpLRU ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE_mdlrr, SRE_bijsp)
fprintf('RMSE: %8.4f %10.4f\n', RMSE_mdlrr, RMSE_bijsp)
fprintf('Time: %8.4f %10.4f\n', cpu_mdlrr/parameter.MaxIter, cpu_bijsp/parameter.MaxIter)

%% display estimated abundance maps
X_true_im    = reshape(X_true', sqrt(size(Y,2)), sqrt(size(Y,2)), size(F,2));
X_mdlrr_im    = reshape(X_mdlrr', sqrt(size(Y,2)), sqrt(size(Y,2)), size(F,2));
X_bijsp_im  = reshape(X_bijsp', sqrt(size(Y,2)), sqrt(size(Y,2)),size(F,2));

close all
figure,colormap('jet')
subplot(131),imagesc(X_true_im(:,:,supp(4)),[0, 1]);
colorbar;title('True--EM #2');
subplot(132),imagesc(X_mdlrr_im(:,:,supp(4)),[0, 1]);
colorbar;title('MdLRR--EM #2');
subplot(133),imagesc(X_bijsp_im(:,:,supp(4)),[0, 1]);
colorbar;title('BiJSpLRU--EM #2');
