function [X] = MdLRR(Y, F, parameter)

K0      = parameter.K0;
numpat  = parameter.numpat;
gamma   = parameter.gamma;
tau     = parameter.tau;
mu      = parameter.mu;
verbose = parameter.verbose;
MaxIter = parameter.MaxIter;

norm_y = sqrt(mean(Y(:).^2));
Y = Y./norm_y;
F = F./norm_y;

epsilon = 1e-5;
[L, K] = size(Y);
m = size(F, 2);

Finv = (F'*F +  6*mu*eye(m))^-1;
W = Finv*F'*Y;
if rem(sqrt(K),1) ~= 0
    error('Initial data errors')
end
mode1 = sqrt(K);
mode2 = sqrt(K);
mode3 = m;


%Initialization of auxiliary matrice??
V1 = W;
V2 = W;
V3 = W;
V43 = W;%V43 is the mode-3 unfolding of V4.tensor;
V53 = W;%V53 is the mode-3 unfolding of V5.tensor;
V6 = W;

%Initialization of Lagranfe Multipliers
D1 = V1*0;
D2 = V2*0;
D3 = V3*0;
D43 = V43*0;
D53 = V53*0;
D6 = V6*0;

%current iteration number
i = 1;

%primal residual
res_p = inf;

%dual residual
res_d = inf;


%error tolerance
tol = sqrt((3*m + L)/2*K/2)*epsilon;

mu_changed = 0;

%---------------------------------------------
%  ADMM iterations
%---------------------------------------------
while (i <= MaxIter) && ((abs(res_p) > tol) || (abs(res_d) > tol))
    if mod(i, 10) == 1
        V10 = V1;
        V20 = V2;
        V30 = V3;
        V430 = V43;
        V530 = V53;
        V60 = V6;
    end
    

    W = Finv*(F'* Y + mu*((V1 + D1) + (V2 + D2) + (V3 + D3)+(V43 + D43)+(V53+D53)+(V6+D6)));
    
    
    % V1
    V1_temp = W-D1;      

    col_k   = 1:numpat(1);
    V1(:,col_k) = vector_soft_row(V1_temp(:,col_k), ...
        gamma/mu* (1./( sqrt(sum(V1_temp(:,col_k).^2,2)) + eps ))+ eps );
    for k = 2:K0   % K0 = length(numpat)
        col_k = (col_k(end)+1) : (col_k(end)+ numpat(k));
        V1(:,col_k) = vector_soft_row(V1_temp(:,col_k), ...
            gamma/mu* (1./( sqrt(sum(V1_temp(:,col_k).^2,2)) + eps ))+ eps );
    end

    
    %V2
    V2_temp = W-D2;    

    V2_temp = rtc(V2_temp,sqrt(size(Y,2)),sqrt(size(Y,2)));

    col_k   = 1:numpat(1);

    V2(:,col_k) = vector_soft_row(V2_temp(:,col_k), ...
        gamma/mu* (1./( sqrt(sum(V2_temp(:,col_k).^2,2)) + eps ))+ eps );
    for k = 2:K0   % K0 = length(numpat)
        col_k = (col_k(end)+1) : (col_k(end)+ numpat(k));
        V2(:,col_k) = vector_soft_row(V2_temp(:,col_k), ...
            gamma/mu* (1./( sqrt(sum(V2_temp(:,col_k).^2,2)) + eps ))+ eps );
    end

    V2=rtc(V2,sqrt(size(Y,2)),sqrt(size(Y,2)));

    
    %V3
    [u,s,v] = svd(W - D3,'econ');
    ds = diag(s);
%     sum(s(1:8))/sum(s(:))
    V3 = u*diag( max( abs(ds) - (tau/mu)*(1./(abs(ds)+ eps)),...
        zeros(size(ds)) ) )*v';
    
    
    %V4
    W_as_tensor = permute(tensor(W,[mode3 mode1 mode2]),[2 3 1]);
    W1 = double(tenmat(W_as_tensor,1));
    D41 = double(tenmat(permute(tensor(D43,[mode3 mode1 mode2]),[2 3 1]),1));
    [u,s,v] = svd(W1 - D41,'econ');
    ds = diag(s);
    V41 = u*diag( max( abs(ds) - (tau/mu)*(1./(abs(ds)+ eps)),...
        zeros(size(ds)) ) )*v';
    V43 = double(tenmat(reshape(V41,[mode1 mode2 mode3]),3));
    
    
    %V5
    W2 = double(tenmat(W_as_tensor,2));
    D52 = double(tenmat(permute(tensor(D53,[mode3 mode1 mode2]),[2 3 1]),2));
    [u,s,v] = svd(W2 - D52,'econ');
    ds = diag(s);
    V52 = u*diag( max( abs(ds) - (tau/mu)*(1./(abs(ds)+ eps)),...
        zeros(size(ds)) ) )*v';
    V53 = double(tenmat(permute(tensor(V52,[mode2 mode1 mode3]),[2 1 3]),3));
    
  
    %V6
    V6 = max(W - D6, 0);
    
    %update D
    D1 = D1 - W + V1;
    D2 = D2 - W + V2;
    D3 = D3 - W + V3;
    D43 = D43 - W + V43;
    D53 = D53 - W + V53;
    D6 = D6 - W + V6;
    
    if mod(i, 10) == 1       
        %primal residual
        res_p = norm([V1; V2; V3; V43; V53; V6] - [W; W; W; W; W; W], 'fro');
        %dual residual
        res_d = mu*norm([V1; V2; V3; V43; V53; V6] - [V10; V20; V30; V430; V530; V60], 'fro');
        
        if verbose
            fprintf('i = %d, res_p = %f, res_d = %f, mu = %f\n',...
                i, res_p, res_d, mu);
        end
        
        if res_p > 10*res_d
            mu = mu*2;
            D1 = D1/2;
            D2 = D2/2;
            D3 = D3/2;
            D43 = D43/2;
            D53 = D53/2;
            D6 = D6/2;
            mu_changed = 1;
        elseif res_d > 10*res_p
            mu = mu/2;
            D1 = D1*2;
            D2 = D2*2;
            D3 = D3*2;
            D43 = D43*2;
            D53 = D53*2;
            D6 = D6*2;
            mu_changed = 1;
        end
        if  mu_changed
            % update Finv
            Finv = (F'*F +  6*mu*eye(m))^-1;
            mu_changed = 0;
            % mu
        end
        
    end
 
    i = i + 1;
end

X = W.*(W>=0);

end
