% demo MSD---for DC1 with SNR = 30 dB
%% load data
close all;clear;clc
load DC1_SNR30.mat

% parameter setting
MaxIter = 500; 
nl      = sqrt(size(Y,2));
nc      = nl;
supp    = find(mean(XT,2)>0); 

%% run algorithms with optimal parameters
% SUnSAL
lambda_s = 0.01;
tic
X_s   = SUnSAL(A,Y,'lambda',lambda_s,'POSITIVITY','yes', ...
      'AL_iters',MaxIter,'TRUE_X',XT);
cpu.s = toc;
  
SRE.s  = 20*log10(norm(XT,'fro')/norm(X_s-XT,'fro'));
RMSE.s = sqrt(mean((X_s(:)-XT(:)).^2));

%% SUnSAL_MSD
lambda_s_msd = 0.05;

tic
X_s_msd = SUnSAL_MSD(A,Y,'lambda',lambda_s_msd,'POSITIVITY','yes', ...
      'AL_iters',MaxIter,'TRUE_X',XT);
cpu.s_msd  = toc;

SRE.s_msd  = 20*log10(norm(XT,'fro')/norm(X_s_msd-XT,'fro'));
RMSE.s_msd = sqrt(mean((X_s_msd(:)-XT(:)).^2));

%% CLSUnSAL
lambda_cls = 1;
tic
X_cls   =  CLSUnSAL(A,Y,'LAMBDA',lambda_cls,'POSITIVITY','yes', ...
              'AL_ITERS',MaxIter,'TRUE_X',XT,'IM_SIZE',[nl,nc]);
cpu.cls = toc;

SRE.cls  = 20*log10(norm(XT,'fro')/norm(X_cls-XT,'fro'));
RMSE.cls = sqrt(mean((X_cls(:)-XT(:)).^2));

%% CLSUnSAL_MSD
lambda_cls_msd  = 0.5;
tic
X_cls_msd    = CLSUnSAL_MSD(A,Y,'LAMBDA',lambda_cls_msd,'POSITIVITY','yes', ...
              'AL_ITERS',MaxIter,'TRUE_X',XT,'IM_SIZE',[nl,nc]);
cpu.cls_msd  = toc;

SRE.cls_msd  = 20*log10(norm(XT,'fro')/norm(X_cls_msd-XT,'fro'));
RMSE.cls_msd = sqrt(mean((X_cls_msd(:)-XT(:)).^2));

%% SUnSAL_TV
lambda_stv    = 0.001;
lambda_tv_stv = 0.01;
mu_stv        = 0.1;

tic
X_stv    = SUnSAL_TV(A,Y,'MU',mu_stv,'TRUE_X',XT,'POSITIVITY','yes', ...
             'LAMBDA_1',lambda_stv,'LAMBDA_TV', lambda_tv_stv, 'TV_TYPE','niso',...
             'IM_SIZE',[nl,nc],'AL_ITERS',MaxIter); 
cpu.stv  = toc;

SRE.stv  = 20*log10(norm(XT,'fro')/norm(X_stv-XT,'fro'));
RMSE.stv = sqrt(mean((X_stv(:)-XT(:)).^2));

%% SUnSAL_TV_MSD
lambda_stv_msd    = 0.005;
lambda_tv_stv_msd = 0.005;
mu_stv_msd        = 0.01;

tic
X_stv_msd    = SUnSAL_TV_MSD(A,Y,'MU',mu_stv_msd,'TRUE_X',XT,'POSITIVITY','yes', ...
             'LAMBDA_1',lambda_stv_msd,'LAMBDA_TV', lambda_tv_stv_msd,...
             'TV_TYPE','niso','IM_SIZE',[nl,nc],'AL_ITERS',MaxIter);
cpu.stv_msd  = toc;            

SRE.stv_msd  = 20*log10(norm(XT,'fro')/norm(X_stv_msd-XT,'fro'));
RMSE.stv_msd = sqrt(mean((X_stv_msd(:)-XT(:)).^2));

%% ADSpLRU
parameter_ads.tau     = 5;
parameter_ads.gamma   = 0.001;
parameter_ads.mu      = 1;
parameter_ads.MaxIter = MaxIter;

tic
X_ads   = ADSpLRU(Y, A, parameter_ads);
cpu.ads  = toc;

SRE.ads   = 20*log10(norm(XT,'fro')/norm(X_ads-XT,'fro'));
RMSE.ads  = sqrt(mean((X_ads(:)-XT(:)).^2));

%% ADSpLRU_MSD
parameter_ads_msd.tau    = 10;
parameter_ads_msd.gamma  = 0.0005;  
parameter_ads_msd.mu     = 1;
parameter_ads_msd.MaxIter = MaxIter;

tic
X_ads_msd    = ADSpLRU_MSD(Y, A,parameter_ads_msd);
cpu.ads_msd  = toc;

SRE.ads_msd  = 20*log10(norm(XT,'fro')/norm(X_ads_msd-XT,'fro'));
RMSE.ads_msd = sqrt(mean((X_ads_msd(:)-XT(:)).^2));

%% JSpBLRU
blocknum = 3;
numpat = blocknum *ones(1, fix(size(Y,2)/blocknum));
numpat(end) = numpat(end) + mod(size(Y,2),blocknum);
if sum(numpat)~= size(Y,2)
    error('block partition does not match!')
end
K0   = length(numpat);  
parameter_jsp.verbose = 0;
parameter_jsp.K0      = K0;
parameter_jsp.MaxIter = MaxIter;
parameter_jsp.numpat  = numpat;
parameter_jsp.gamma   = 0.005;
parameter_jsp.tau     = 5;
parameter_jsp.mu      = 1;

tic
X_jsp    = JSpBLRU(Y,A,parameter_jsp);
cpu.jsp  = toc;

SRE.jsp  = 20*log10(norm(XT,'fro')/norm(X_jsp-XT,'fro'));
RMSE.jsp = sqrt(mean((X_jsp(:)-XT(:)).^2));

%% JSpBLRU_MSD
parameter_jsp_msd        = parameter_jsp;
parameter_jsp_msd.gamma  = 0.005;
parameter_jsp_msd.tau    = 5;
parameter_jsp_msd.mu     = 0.1;

tic
X_jsp_msd    = JSpBLRU_MSD(Y,A,parameter_jsp_msd);
cpu.jsp_msd  = toc;

SRE.jsp_msd  = 20*log10(norm(XT,'fro')/norm(X_jsp_msd-XT,'fro'));
RMSE.jsp_msd = sqrt(mean((X_jsp_msd(:)-XT(:)).^2));

%% display SRE and RMSE values
clc
disp(['       ', 'SUnSAL    ', ' SUnSAL-MSD ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE.s, SRE.s_msd)
fprintf('RMSE: %8.4f %10.4f\n', RMSE.s, RMSE.s_msd)
fprintf('Time: %8.4f %10.4f\n\n', cpu.s, cpu.s_msd)

disp(['       ', 'CLSUnSAL  ', ' CLSUnSAL-MSD ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE.cls, SRE.cls_msd)
fprintf('RMSE: %8.4f %10.4f\n', RMSE.cls, RMSE.cls_msd)
fprintf('Time: %8.4f %10.4f\n\n', cpu.cls, cpu.cls_msd)

disp(['       ', 'SUnSAL-TV ', ' SUnSAL-TV-MSD ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE.stv, SRE.stv_msd)
fprintf('RMSE: %8.4f %10.4f\n', RMSE.stv, RMSE.stv_msd)
fprintf('Time: %8.4f %10.4f\n\n', cpu.stv, cpu.stv_msd)

disp(['       ', 'ADSpLRU   ', ' ADSpLRU-MSD ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE.ads, SRE.ads_msd)
fprintf('RMSE: %8.4f %10.4f\n', RMSE.ads, RMSE.ads_msd)
fprintf('Time: %8.4f %10.4f\n\n', cpu.ads, cpu.ads_msd)

disp(['       ', 'JSpBLRU   ', ' JSpBLRU-MSD ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE.jsp, SRE.jsp_msd)
fprintf('RMSE: %8.4f %10.4f\n', RMSE.jsp, RMSE.jsp_msd)
fprintf('Time: %8.4f %10.4f\n', cpu.jsp, cpu.jsp_msd)

%% display estimated abundance maps
n = size(A,2);
Xtrue_im      = reshape(XT', nl, nc, n);
X_s_im        = reshape(X_s', nl, nc, n);
X_s_msd_im    = reshape(X_s_msd', nl, nc,n);
X_cls_im      = reshape(X_cls', nl, nc, n);
X_cls_msd_im  = reshape(X_cls_msd', nl, nc,n);
X_stv_im      = reshape(X_stv', nl, nc, n);
X_stv_msd_im  = reshape(X_stv_msd', nl, nc,n);
X_ads_im      = reshape(X_ads', nl, nc, n);
X_ads_msd_im  = reshape(X_ads_msd', nl, nc,n);
X_jsp_im      = reshape(X_jsp', nl, nc, n);
X_jsp_msd_im  = reshape(X_jsp_msd', nl, nc,n);

k = 1; % show abundance maps for endmember #1
figure,colormap('jet')
subplot(531),imagesc(Xtrue_im(:,:,supp(k)),[0, 1]);
colorbar;title(['True' num2str(k)]);
subplot(532),imagesc(X_s_im(:,:,supp(k)),[0, 1]);
colorbar;title('SUnSAL');
subplot(533),imagesc(X_s_msd_im(:,:,supp(k)),[0, 1]);
colorbar;title('SUnSAL-MSD');

subplot(535),imagesc(X_cls_im(:,:,supp(k)),[0, 1]);
colorbar;title('CLSUnSAL');
subplot(536),imagesc(X_cls_msd_im(:,:,supp(k)),[0, 1]);
colorbar;title('CLSUnSAL-MSD');

subplot(538),imagesc(X_stv_im(:,:,supp(k)),[0, 1]);
colorbar;title('SUnSAL-TV');
subplot(539),imagesc(X_stv_msd_im(:,:,supp(k)),[0, 1]);
colorbar;title('SUnSAL-TV-MSD');

subplot(5,3,11),imagesc(X_ads_im(:,:,supp(k)),[0, 1]);
colorbar;title('ADSpLRU');
subplot(5,3,12),imagesc(X_ads_msd_im(:,:,supp(k)),[0, 1]);
colorbar;title('ADSpLRU-MSD');

subplot(5,3,14),imagesc(X_jsp_im(:,:,supp(k)),[0, 1]);
colorbar;title('JSpBLRU');
subplot(5,3,15),imagesc(X_jsp_msd_im(:,:,supp(k)),[0, 1]);
colorbar;title('JSpBLRU-MSD');


