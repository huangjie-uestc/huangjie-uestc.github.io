
function [U1,res,rmse] = SUnSAL_TV_MSD(M,Y,varargin)
if (nargin-length(varargin)) ~= 2
    error('Wrong number of required parameters');
end
% mixing matrix size
[LM,n] = size(M);
% data set size
[L,N] = size(Y);
if (LM ~= L)
    error('mixing matrix M and data set y are inconsistent');
end
reg_l1 = 0; % absent
reg_TV = 0; % absent
im_size = []; % image size
tv_type = 'niso'; % non-isotropic TV
AL_iters = 1000;
mu = 0.001;
verbose = 'off';
positivity = 'no';
reg_pos = 0; % absent
addone = 'no';
reg_add = 0; % absent
U0 = 0;
true_x = 0;
rmse = 0;
if (rem(length(varargin),2)==1)
    error('Optional parameters should always go by pairs');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'LAMBDA_1'
                lambda_l1 = varargin{i+1};
                if lambda_l1 < 0
                    error('lambda must be positive');
                elseif lambda_l1 > 0
                    reg_l1 = 1;
                end
            case 'LAMBDA_TV'
                lambda_TV = varargin{i+1};
                if lambda_TV < 0
                    error('lambda must be non-negative');
                elseif lambda_TV > 0
                    reg_TV = 1;
                end
            case 'TV_TYPE'
                tv_type = varargin{i+1};
                if ~(strcmp(tv_type,'iso') | strcmp(tv_type,'niso'))
                    error('wrong TV_TYPE');
                end
            case 'IM_SIZE'
                im_size = varargin{i+1};
            case 'AL_ITERS'
                AL_iters = round(varargin{i+1});
                if (AL_iters <= 0 )
                    error('AL_iters must a positive integer');
                end
            case 'POSITIVITY'
                positivity = varargin{i+1};
                if strcmp(positivity,'yes')
                    reg_pos = 1;
                end
            case 'MU'
                mu = varargin{i+1};
                if mu <= 0
                    error('mu must be positive');
                end
            case 'VERBOSE'
                verbose = varargin{i+1};
            case 'X0'
                U0 = varargin{i+1};
            case 'TRUE_X'
                XT = varargin{i+1};
                true_x = 1;
            otherwise
                % Hmmm, something wrong with the parameter string
                error(['Unrecognized option: ''' varargin{i} '''']);
        end;
    end;
end

% test for true data size correctness
if true_x
    [nr nc] = size(XT);
    if (nr ~= n) | (nc ~= N)
        error('wrong image size')
    end
end


% test for image size correctness
if reg_TV > 0
    if N ~= prod(im_size)
        error('wrong image size')
    end
    n_lin = im_size(1);
    n_col = im_size(2);
    
    % build handlers and necessary stuff
    % horizontal difference operators
    FDh = zeros(im_size);
    FDh(1,1) = -1;
    FDh(1,end) = 1;
    FDh = fft2(FDh);
    FDhH = conj(FDh);
    
    % vertical difference operator
    FDv = zeros(im_size);
    FDv(1,1) = -1;
    FDv(end,1) = 1;
    FDv = fft2(FDv);
    FDvH = conj(FDv);
    
    IL = 1./( FDhH.* FDh + FDvH.* FDv + 1);
    
    Dh = @(x) real(ifft2(fft2(x).*FDh));
    DhH = @(x) real(ifft2(fft2(x).*FDhH));
    
    Dv = @(x) real(ifft2(fft2(x).*FDv));
    DvH = @(x) real(ifft2(fft2(x).*FDvH));
    
end
if ~reg_TV && ~reg_l1 && ~reg_pos && ~reg_add
    U = pinv(M)*Y;
    res = norm(M*X-Y,'fro');
    return
end
SMALL = 1e-12;
B = ones(1,n);
a = ones(1,N);

if  ~reg_TV && ~reg_l1 && ~reg_pos && reg_add
    F = M'*M;
    % test if F is invertible
    if rcond(F) > SMALL
        % compute the solution explicitly
        IF = inv(F);
        U = IF*M'*Y-IF*B'*inv(B*IF*B')*(B*IF*M'*Y-a);
        res = norm(M*U-Y,'fro');
        return
    end
    % if M'*M is singular, let sunsal_tv run
end
n_reg =  reg_l1 + reg_pos+ reg_TV;

IF = inv(M'*M + 3*eye(n));
if U0 == 0
    U = IF*M'*Y;
end

index = 1;
% initialize V variables
V = cell(4,1);

% initialize D variables (scaled Lagrange Multipliers)
D = cell(4,1);
%  data term (always present)
reg(1) = 1;             % regularizers
V{index} = M*U;         % V1
D{1} = zeros(size(Y));  % Lagrange multipliers
% next V
index = index + 1;
% POSITIVITY
if reg_pos == 1
    reg(index) = 2;
    V{index} = U;
    D{index} = zeros(size(U));
    index = index +1;
end
if reg_l1 == 1
    reg(index) = 3;
    V{index} = U;
    D{index} = zeros(size(U));
    index = index +1;
end
%TV
% NOTE: V5, V6, D5, and D6 are represented as image planes
if reg_TV == 1
    reg(index) = 4;
    % V5
    V{index} = U;
    D{index} = zeros(size(U));
    
    % convert X into a cube
    U_im = reshape(U',im_size(1), im_size(2),n);
    
    % V6 create two images per band (horizontal and vertical differences)
    V{index+1} = cell(n,2);
    D{index+1} = cell(n,2);
    for i=1:n
        % build V6 image planes
        V{index+1}{i}{1} = Dh(U_im(:,:,i));   % horizontal differences
        V{index+1}{i}{2} = Dv(U_im(:,:,i));   % horizontal differences
        % build d7 image planes
        D{index+1}{i}{1} = zeros(im_size);   % horizontal differences
        D{index+1}{i}{2} = zeros(im_size);   % horizontal differences
    end
    clear U_im;
end
%main body
tol1=sqrt(N)*1e-5;
res=inf;
i=1;
Q=[1:n];%Initialize the original index set
P1=cell(1,n);%the original index set of non-active endmember in iteration 
P2=cell(1,n);%non-active endmember index set in iteration

while(i<=AL_iters)&&(sum(abs(res))>tol1)
    U=IF*(M'*(V{1}+D{1})+V{2}+D{2}+V{3}+V{4}+D{3}+D{4});
    T=size(Q,2);%Number of remaining rows
    R=[1:T];% Initialize the index set for each iteration
    P1{i}=[];
    P2{i}=[];
    t1=1;
    T_1=[];
    T_2=[];
    for t_1=1:T
        T_1(t_1)=norm(U(t_1,:),2);%Calculate the L2-norm value of each row of the abundance matrix
    end
    [T_1,Y_1]=sort(T_1,'descend');%descend
    t_2=1;
    while(t_2<=T-1)%Calculate the difference
         T_2(t_2)=T_1(t_2)-T_1(t_2+1);
         if(T_1(t_2)<mean(T_1)&&T_2(t_2)<0.0005)% conditions
             break;
         else
             t_2=t_2+1;
         end
    end
   Threshold=T_1(t_2);%Threshold
   for t=1:T
        if (norm(U(t,:),2)<Threshold)
            P1{i}(t1)=Q(t);%the original index set of non-active endmember at iteration
            P2{i}(t1)=t;%the index set of non-active endmember in iteration
            t1=t1+1;
        end
   end
    [~,id]=ismember(P1{i},Q);%the original index set of active endmember at iteration
    Q(id)=[];
    [~,id]=ismember(P2{i},R);%the index set of active endmember in iteration
    R(id)=[];
    Qsize=size(Q,2);
    U(P2{i},:)=[];%update U
    M(:,P2{i})=[];%update M
    IF = inv(M'*M + 3*eye(Qsize));%update IF 
    %update D
    D{2}(P2{i},:)=[];
    D{3}(P2{i},:)=[];
    D{4}(P2{i},:)=[];      
    for j=1:4
         %  data term (V1)
        if  reg(j) == 1
            V{j} = (1/(1+mu)*(Y+mu*(M*U-D{j})));
        end
         %  positivity   (V2)
        if  reg(j) == 2
            V{j} = max(U-D{j},0);
        end
        % l1 norm  (V3)
        if  reg(j) == 3
            V{j} = soft(U-D{j},lambda_l1/mu);
        end
        % TV  (V4 and V5)
        if reg(j)==4
      % update V5: solves the problem:
            %    min 0.5*||L*V4-(V5+D6)||^2+0.5*||V4-(U-d4)||^2
            %      V4
            %
            % update V6: min 0.5*||V5-(L*V4-D5)||^2 + lambda_tv * |||V5||_{1,1}
            nu_aux = U - D{j};
             % convert nu_aux into image planes
            % convert X into a cube
            nu_aux4_im = reshape(nu_aux',im_size(1), im_size(2),Qsize);
             % compute V5 in the form of image planes
            for k =1:Qsize  
                 % V4
                V4_im(:,:,k)=real(ifft2(IL.*fft2(DhH(V{j+1}{R(k)}{1}+D{j+1}{R(k)}{1}) ...
                    +  DvH(V{j+1}{R(k)}{2}+D{j+1}{R(k)}{2}) +  nu_aux4_im(:,:,k)))); 
                V{j}(k,:)=reshape(V4_im(:,:,k),prod(im_size),1)';% convert V4 to vector format
                % V5
                aux_h = Dh(V4_im(:,:,k));
                aux_v = Dv(V4_im(:,:,k));
                if strcmp(tv_type, 'niso')  % non-isotropic TV
                    V{j+1}{k}{1} = soft(aux_h - D{j+1}{R(k)}{1}, lambda_TV/mu);   %horizontal
                    V{j+1}{k}{2} = soft(aux_v - D{j+1}{R(k)}{2}, lambda_TV/mu);   %vertical
                else    % isotropic TV
                    % Vectorial soft threshold
                    aux = max(sqrt((aux_h - D{j+1}{R(k)}{1}).^2 + (aux_v - D{j+1}{R(k)}{2}).^2)-lambda_TV/mu,0);
                    V{j+1}{k}{1} = aux./(aux+lambda_TV/mu).*(aux_h - D{j+1}{R(k)}{1});
                    V{j+1}{k}{2} = aux./(aux+lambda_TV/mu).*(aux_v - D{j+1}{R(k)}{2});
                end
                D{j+1}{k}{1} =  D{j+1}{R(k)}{1} - (aux_h - V{j+1}{k}{1});
                D{j+1}{k}{2} =  D{j+1}{R(k)}{2} - (aux_v - V{j+1}{k}{2});               
            end
        end
    end
    %update V4
    [T3,~]=size(V{4});
    T5=[Qsize+1:T3];
    V{4}(T5,:)=[];
    if mod(i,10) == 1
        st = [];
        for j=1:4
            if  reg(j) == 1
                res(j) = norm(M*U-V{j},'fro');
                st = strcat(st,sprintf(' res(%i) = %2.6f',reg(j),res(j) ));
            else
                res(j) = norm(U-V{j},'fro');
                st = strcat(st,sprintf('  res(%i) = %2.6f',reg(j),res(j) ));
            end
        end
        if  strcmp(verbose,'yes')
            fprintf(strcat(sprintf('iter = %i -',i),st,'\n'));
        end
    end
  
    % update Lagrange multipliers
    for j=1:4
        if  reg(j) == 1
            D{j} = D{j} - (M*U-V{j});
        else
            D{j} = D{j} - (U-V{j});
        end
    end
    if true_x
        U1=zeros(n,N);
        U1(Q,:)=U(1:Qsize,:);
        rmse(i)= norm(U1-XT,'fro');
        if  strcmp(verbose,'yes')
            fprintf(strcat(sprintf('iter = %i - ||Xhat - X|| = %2.3f',i, rmse(i)),'\n'));
        end
     end
     
    i=i+1;
end
U(U<0)=0;

  
