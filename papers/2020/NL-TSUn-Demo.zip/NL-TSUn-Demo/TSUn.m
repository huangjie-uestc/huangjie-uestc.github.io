function X = TSUn(Y1, F, parameter)
% parameter setting
lambda1  = parameter.lambda1;
lambda2  = parameter.lambda2;
mu       = parameter.mu;
verbose  = parameter.verbose;
MaxIter  = parameter.MaxIter;

% input tensor Y1
Num.em      = size(F, 2); % number of endmembers
Num.pixel   = size(Y1,1); % number of pixels in one patch
Num.band    = size(Y1,2); % number of bands
Num.SimiPat = size(Y1,3); % number of similar patches
dimY1       = size(Y1);

norm_y = sqrt(mean(Y1(:).^2));
Y1     = Y1./norm_y;
F      = F./norm_y;

% From input tensor Y1 to Matrix Y
Y = Unfold(Y1, dimY1, 2);

% initial tensor X
dimX = [Num.pixel, Num.em, Num.SimiPat];
Finv = (F'*F +  mu*eye(Num.em))^-1;
X_2  = Finv*F'*Y; % original initialization
X    = Fold(X_2, dimX, 2); % tensor X;

%Initialization of auxiliary matrices M{j} and Lagranfe Multipliers
for j = 1:6
    M{j} = X;
    D{j} = M{j}*0;
end

%Initialization of Unfold matrix of M{j}
M1_2 = zeros(size(Unfold(M{1},dimX, 2)));
M2_2 = zeros(size(Unfold(M{2},dimX, 2)));
M3_1 = zeros(size(Unfold(M{3},dimX, 1)));
M4_2 = zeros(size(Unfold(M{4},dimX, 2)));
M5_3 = zeros(size(Unfold(M{5},dimX, 3)));
M6_2 = zeros(size(Unfold(M{6},dimX, 2)));

%current iteration number
i = 1;
%primal residual
res_p = inf;
%dual residual
res_d = inf;
%error tolerance
epsilon = 1e-5;
tol = sqrt((3*Num.em + Num.band)/2*Num.pixel/2)*epsilon;
%initial mu
mu_changed = 0;

while (i <= MaxIter) && ((abs(res_p) > tol) || (abs(res_d) > tol))
    if mod(i, 10) == 1
        M1_2_0 = M1_2;
        M2_2_0 = M2_2;
        M3_1_0 = M3_1;
        M4_2_0 = M4_2;
        M5_3_0 = M5_3;
        M6_2_0 = M6_2;
    end
    
    % M1
    X_2  = Unfold(X, dimX, 2);
    D1_2 = Unfold(D{1}, dimX, 2);
    M1_2 = Finv*(F'* Y + mu*(X_2-D1_2) );
    M{1} = Fold(M1_2,dimX,2);
    
    % M2
    D2_2 = Unfold(D{2}, dimX, 2);
    temp_M2_2 = X_2-D2_2;
    for k = 1:Num.pixel
        col = Num.SimiPat*(k-1)+1:Num.SimiPat*k;
        temp_M2_2_k = temp_M2_2(:,col);
        M2_2(:,col) = vector_soft_row(temp_M2_2_k, ...
            lambda1/mu* (1./( sqrt(sum(temp_M2_2_k.^2,2)) + eps ))+ eps );
    end
    M{2} = Fold(M2_2,dimX,2);
    
    % M3
    X_1  = Unfold(X, dimX, 1);
    D3_1 = Unfold(D{3}, dimX, 1);
    [u3,s3,v3] = svd(X_1 - D3_1,'econ');
    ds3  = diag(s3);
    M3_1 = u3*diag( max( abs(ds3) - (lambda2/mu)*(1./(abs(ds3)+ eps)),...
        zeros(size(ds3)) ) )*v3';  % with weights
    M{3} = Fold(M3_1, dimX, 1);
    
    % M4
    D4_2 = Unfold(D{4}, dimX, 2);
    [u4,s4,v4] = svd(X_2 - D4_2,'econ');
    ds4 = diag(s4);
    M4_2 = u4*diag( max( abs(ds4) - (lambda2/mu)*(1./(abs(ds4)+ eps)),...
        zeros(size(ds4)) ) )*v4';  % with weights
    M{4} = Fold(M4_2, dimX, 2);
    
    % M5
    X_3  = Unfold(X, dimX, 3);
    D5_3 = Unfold(D{5}, dimX, 3);
    [u5,s5,v5] = svd(X_3 - D5_3,'econ');
    ds5 = diag(s5);
    M5_3 = u5*diag( max( abs(ds5) - (lambda2/mu)*(1./(abs(ds5)+ eps)),...
        zeros(size(ds5)) ) )*v5';  % with weights
    M{5} = Fold(M5_3, dimX, 3);
    
    % M6
    M{6} = max(X - D{6}, 0);
    M6_2 = Unfold(M{6}, dimX, 2);
    
    % X
    X = 1/6*(M{1}+D{1} + M{2}+D{2} + M{3}+D{3} + M{4}+D{4} + M{5}+D{5} + M{6}+D{6});
    
    for j = 1:6
        D{j} = D{j} - X + M{j};
    end
    
    if mod(i, 10) == 1
        
        %primal residual
        temp1 = [M{1}; M{2}; M{3}; M{4}; M{5}; M{6}] - [X;X;X;X;X;X];
        res_p = sqrt(sum((temp1(:)).^2));
        %dual residual
        temp21 = M1_2-M1_2_0;
        temp22 = M2_2-M2_2_0;
        temp23 = M3_1-M3_1_0;
        temp24 = M4_2-M4_2_0;
        temp25 = M5_3-M5_3_0;
        temp26 = M6_2-M6_2_0;
        temp2 = temp21(:).^2 + temp22(:).^2 +temp23(:).^2 +temp24(:).^2+...
            temp25(:).^2 + temp26(:).^2;
        res_d = mu* sqrt(sum(temp2));
        
        if verbose
            fprintf('i = %d, res_p = %f, res_d = %f, mu = %f\n',...
                i, res_p, res_d, mu);
        end
        
        if res_p > 10*res_d
            mu = mu*2;
            for j = 1:6
                D{j} = D{j}/2;
            end
            mu_changed = 1;
        elseif res_d > 10*res_p
            mu = mu/2;
            for j = 1:6
                D{j} = D{j}*2;
            end
            mu_changed = 1;
        end
        if  mu_changed
            % update Finv
            Finv = (F'*F +  mu*eye(Num.em))^-1;
            mu_changed = 0;
            % mu
        end
        
    end
    
    i = i + 1;
    
end

X = X.*(X>=0);

end
