function [XhsiMat] = NL_TSUn(A,Y, parameter, par)
%% get similar fullband patches
sizeYhsi = [sqrt(size(Y,2)), sqrt(size(Y,2)),size(Y,1)];% size of Yhsi
sizeXhsi = [sizeYhsi(1), sizeYhsi(2),size(A,2)];        % size of Xhsi
Yhsi     = reshape(Y',sizeYhsi); % HSI tensor

[Sel_arr]       = nonLocal_arr(sizeYhsi, par); % PreCompute the all the patch index in the searching window
L               = length(Sel_arr);    % number of keypatches in nonLocal_arr

%% bulit group data based on similiar patches
Curmsi          = Yhsi;
Curpatch        = Im2Patch3D(Curmsi, par); % image to FBPs
sizePatch       = size(Curpatch);
clear Curmsi
% block matching to find samilar FBP goups
unfoldPatch     = Unfold(Curpatch,sizePatch,3)';
patchXpatch     = sum(unfoldPatch.*unfoldPatch,1);
distenMat       = repmat(patchXpatch(Sel_arr),sizePatch(3),1)+repmat(patchXpatch',1,L)-2*(unfoldPatch')*unfoldPatch(:,Sel_arr);
[~,index]       = sort(distenMat);
index           = index(1:par.patnum,:);
clear patchXpatch distenMat;

tempPatch       = cell(L,1);
for i = 1:L 
    tempPatch{i} = Curpatch(:,:,index(:,i));
end

clear Curpatch unfoldPatch Curmsi

parfor i = 1:L
    disp([i,L])
    tempPatch_Out{i} = TSUn(tempPatch{i},A,parameter); % Perform JSBLR tensor recovery on each FBP goup
end

%% rebuilt the recovered data
sizeXPatch      = [sizePatch(1), size(A,2), sizePatch(3)]; % 36*120*50 similar abundance patches
Epatch          = zeros(sizeXPatch);
W               = zeros(sizePatch(1),sizePatch(3));
for i = 1:L
    Epatch(:,:,index(:,i))  = Epatch(:,:,index(:,i)) + tempPatch_Out{i};
    W(:,index(:,i))         = W(:,index(:,i))+ones(size(tempPatch_Out{i},1),size(tempPatch_Out{i},3));
end

[Xhsi, ~]  =  Patch2Im3D( Epatch, W, par, sizeXhsi); % recconstruct the estimated MSI by aggregating all reconstructed FBP goups.

clear W Epatch 

XhsiMat = reshape(Xhsi,[sizeXhsi(1)*sizeXhsi(2), sizeXhsi(3)]);
XhsiMat = XhsiMat';

XhsiMat = XhsiMat.*(XhsiMat>=0);

end

