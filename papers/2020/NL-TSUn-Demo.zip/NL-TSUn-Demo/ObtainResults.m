function [RMSE_comp, SRE_comp] = ObtainResults(Wtrue, W_comp)
RMSE_comp = sqrt(mean( (Wtrue(:) - W_comp(:)).^2 ) );
RMSE_comp = round(10000*RMSE_comp)/10000;

SRE_comp = 10*log10( sum(Wtrue(:).^2) / sum( (Wtrue(:) - W_comp(:)).^2 ) );
SRE_comp = round(10000*SRE_comp)/10000;