%% NL-TSUn for paper 
% J. Huang*, T.-Z. Huang*, X.-L. Zhao, L.-J. Deng, 
% Nonlocal Tensor-based Sparse Hyperspectral Unmixing��
% IEEE TGRS, 2020, DOI :10.1109/TGRS.2020.3030233

%% load data
close all; clear
load Example1_synthetic_data_SNR20
% parameter setting
maxiter   = 500;  %the maximum iteration
parameter.lambda1 = 0.1;
parameter.lambda2 = 0.5;
parameter.mu      = 1;
parameter.verbose = 0;
parameter.MaxIter = maxiter;

par.patsize       =   25;   % Patch size
par.patnum        =   10;   % similar patch numbers
par.step          =   floor((par.patsize-1));
par.delta         =   0.1;
%% run NL-TSUn
tic
[Out.X_hat] = NL_TSUn(A, Y,parameter, par);
Out.cpu = toc;

[Out.RMSE,Out.SRE] = ObtainResults(X_true,Out.X_hat);

%% display abundance maps
close all;
figure(1),colormap('jet')
subplot(1,2,1), imagesc(reshape(X_true(sel(9),:),100,100));colorbar
title('True');
subplot(1,2,2), imagesc(reshape(Out.X_hat(sel(9),:),100,100));colorbar
title('NL-TSUn');

