clear
clc
%%  Generate data 
p = 9;   % number of end members % fixed for this demo
SNR =30; % SNR in dB

% gererate fractional abundances
load materials % L is the library
L=L(1:end-1,2:121);
A=L;

[bl,nm]=size(A); % nm is the number of materials and bl is the number of bands
N=100*100; % number of total pixel
nl=sqrt(N);nc=sqrt(N);
sel=[11    46    20    36    62    76     49    97    86];
% true fractional abundance
X_true=zeros(nm,N);

for i = 1:p
    str = sprintf('I=double(imread(''endmember%d.bmp''))/256;', i);
    eval(str);
    eval(sprintf('I%d=I(:,:,1);',i));
end

% normalization
s=I1+I2+I3+I4+I5+I6+I7+I8+I9;
s(s==0)=1;
for i = 1:p
    eval(sprintf('I%d=I%d./s;',i,i));
end

F=[I1(:),I2(:),I3(:),I4(:),I5(:),I6(:),I7(:),I8(:),I9(:)]';
for i=1:p
    X_true(sel(i),:)=F(i,:);
end

% linear mixture
Y    = A*X_true;

% add noise
Sigma = sqrt((sum(Y(:).^2)/(N*bl))/(10^(SNR/10)));
% observed noisy hyperspectral data
Y = Y +Sigma*randn(bl,N);

%% sunsal-bf-tv
lambda    = 1e-3;
lambda_tv = 5e-3;
mu        = 0.1;
maxiter   = 500;
[X,SRE]   = SUnSAL_bftv(Y,A,X_true,lambda,lambda_tv,mu,maxiter,nl,nc,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% print results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n\n SIGNAL-TO-RECONSTRUCTION ERRORS (SRE)\n\n')
fprintf('SRE-sunsal-bftv = %2.3f\n\n', SRE(end))

Xtrue_im = reshape(X_true', nl,nc,nm);       
X_im     = reshape(X', nl,nc,nm);       
figure (1),
subplot(121),imagesc(Xtrue_im(:,:,sel(9)));title('true')
subplot(122),imagesc(X_im(:,:,sel(9)));title('SUnSAL-BF-TV')

