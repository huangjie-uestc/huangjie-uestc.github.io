function X=D1(X,n1,n2) %%% diff operator in vectical direction
for i=1:n2
    temp=X(((i-1)*n1+1):(i*n1),:);
    X(((i-1)*n1+1):(i*n1),:)=[temp(2:end,:);temp(1,:)]-temp;
end
