function X=D1T(X,n1,n2) %%%transpose of diff operator in vectical direction
for i=1:n1
    temp=X(((i-1)*n1+1):(i*n1),:);
    X(((i-1)*n1+1):(i*n1),:)=[temp(end,:);temp(1:end-1,:)]-temp;
end
