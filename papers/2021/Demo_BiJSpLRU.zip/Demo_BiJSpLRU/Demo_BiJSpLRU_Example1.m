% demo BiJSpLRU
%% Example 1 
clear;clc;
SNR = 30;
p   = 5;   % number of material
np  = 225; % number of pixels
nl  = 15;
nc  = 15;
%% generate true abundance matrix Xsupp
Xsupp    = zeros(p,np);
k1       = zeros(nl,nc);
k1(2,:)  = 0.3;
k1(5,:)  = 0.35;
k1(8,:)  = 0.4;
k1(11,:) = 0.45;
k1(14,:) = 0.5;
k2       = k1';
Xsupp(1,:) = reshape(k1,1,np);
Xsupp(2,:) = reshape(k2,1,np);
for i = 3:4
    for j=1:np
        Xsupp(i,j) = (1-sum(Xsupp(:,j)))*rand;
    end
end
Xsupp(5,:) = ones(1,np) - sum(Xsupp);
            
%% generate true library A
load USGS_1995_Library.mat
%  order bands by increasing wavelength
[dummy, index] = sort(datalib(:,1));
A =  datalib(index,4:end);
% prune the library 
% min angle (in degres) between any two signatures 
% the larger min_angle the easier is the sparse regression problem
min_angle = 4.44;       
A = prune_library(A,min_angle); % 240  signature 
% order  the columns of A by decreasing angles 
[A, index, angles] = sort_library_by_angle(A);

% select p endmembers from A
supp  = 1:p;
M     = A(:,supp);
[L,p] = size(M);  % L = number of bands; 

%% generate the observed data Y
% set noise standard deviation
sigma = sqrt(sum(sum((M*Xsupp).^2))/np/L/10^(SNR/10));
% generate Gaussian iid noise
noise = sigma*randn(L,np);
% construct noisy reflective matrix
Y = M*Xsupp + noise;

% create true X wrt the library A
n = size(A,2);
Xtrue = zeros(n,np);
Xtrue(supp,:) = Xsupp;

%% parameter setting for JSpBLRU and BiJSpLRU
% partition strategy for Xtrue
blocknum = 3;
numpat = blocknum *ones(1, fix(size(Y,2)/blocknum));
numpat(end) = numpat(end) + mod(size(Y,2),blocknum);
if sum(numpat)~= size(Y,2)
    error('block partition does not match!')
end

K0      = length(numpat);  % number of blocks
maxiter = 300;
parameter.verbose = 0;
parameter.K0      = K0;
parameter.MaxIter = maxiter;
parameter.numpat  = numpat;

% choose optimal parameters from the following sequence
Gamma = [0.0001,0.0005,0.001,0.005,0.01,0.05,0.1,0.5];
Tau   = [0.001,0.005,0.01,0.05,0.1,0.5,1,5,10,50,100];
Mu    = [0.001 0.01 0.1 1];

no_l1 = length(Gamma);
no_l2 = length(Tau);
no_l3 = length(Mu);

%% Choose optimal parameters for JSpBLRU
SRE_temp_jsp = zeros(no_l1,no_l2,no_l3);
kk0 = waitbar(0, 'Searching optimal parameters for JSpBLRU ...');
kk = 1;
for j1=1:no_l1  % sparse 
    for j2 = 1:no_l2  % lowrank
        for j3 = 1:no_l3   % mu
            waitbar(kk/(no_l1*no_l2*no_l3), kk0)
            kk = kk+1;
            parameter.gamma  = Gamma(j1);
            parameter.tau    = Tau(j2);
            parameter.mu     = Mu(j3);
            X_jsp            = JSpBLRU(Y,A,parameter);
            SRE_temp_jsp(j1,j2,j3) = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_jsp(:)).^2 ) );
        end
    end
end
close(kk0)
            
[~,ind] = max(SRE_temp_jsp(:));
[par_sp,par_rank,par_mu] = ind2sub(size(SRE_temp_jsp),ind);
parameter.gamma  = Gamma(par_sp);
parameter.tau    = Tau(par_rank);
parameter.mu     = Mu(par_mu);

%% run JSpBLRU with optimal parameters
tic
X_jsp = JSpBLRU(Y,A,parameter);
cpu_jsp = toc;

SRE_jsp  = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_jsp(:)).^2 ) );
RMSE_jsp = sqrt(mean((X_jsp(:) - Xtrue(:)).^2));

%% choose optimal parameters for BiJSpLRU
SRE_temp_bijsp = zeros(no_l1,no_l2,no_l3);
kk0 = waitbar(0, 'Searching optimal parameters for BiJSpLRU ...');
kk = 1;
for j1=1:no_l1
    for j2 = 1:no_l2
        for j3= 1:no_l3
            waitbar(kk/(no_l1*no_l2*no_l3), kk0)
            kk = kk+1;
            parameter.gamma  = Gamma(j1);
            parameter.tau    = Tau(j2);
            parameter.mu     = Mu(j3);
            X_bijsp          = BiJSpLRU(Y,A,parameter);
            SRE_temp_bijsp(j1,j2,j3) = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_bijsp(:)).^2 ) );
        end
    end
end
close(kk0)

[~,ind ]          = max(SRE_temp_bijsp(:));
[par_sp,par_rank,par_mu] = ind2sub(size(SRE_temp_bijsp),ind);
parameter.gamma   = Gamma(par_sp);
parameter.tau     = Tau(par_rank);
parameter.mu      = Mu(par_mu);

%% run BiJSpBLRU with optimal parameters
tic
X_bijsp   = BiJSpLRU(Y,A,parameter);
cpu_bijsp = toc;

SRE_bijsp  = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_bijsp(:)).^2 ) );
RMSE_bijsp = sqrt(mean((X_bijsp(:) - Xtrue(:)).^2));

%% display SRE and RMSE values
% clc
disp(['       ', 'JSpBLRU  ', ' BiJSpLRU ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE_jsp, SRE_bijsp)
fprintf('RMSE: %8.4f %10.4f\n', RMSE_jsp, RMSE_bijsp)
fprintf('Time: %8.4f %10.4f\n', cpu_jsp, cpu_bijsp)

%% display estimated abundance maps
Xtrue_im    = reshape(Xtrue', nl, nc, n);
X_jsp_im    = reshape(X_jsp', nl, nc, n);
X_bijsp_im  = reshape(X_bijsp', nl, nc,n);

close all
figure,colormap('jet')
subplot(231),imagesc(Xtrue_im(:,:,1),[0, 1]);
colorbar;title('True--EM 1');
subplot(232),imagesc(X_jsp_im(:,:,1),[0, 1]);
colorbar;title('JSpBLRU--EM 1');
subplot(233),imagesc(X_bijsp_im(:,:,1),[0, 1]);
colorbar;title('BiJSpLRU--EM 1');

subplot(234),imagesc(Xtrue_im(:,:,2),[0, 1]);
colorbar;title('True--EM 2');
subplot(235),imagesc(X_jsp_im(:,:,2),[0, 1]);
colorbar;title('JSpBLRU--EM 2');
subplot(236),imagesc(X_bijsp_im(:,:,2),[0, 1]);
colorbar;title('BiJSpLRU--EM 2');