%% demo BiJSpLRU---Example 3
%% load data
clear;clc;
load Example3_snr30.mat
SNR_est = 10*log10(sum(sum((A*Xtrue).^2))/sum(sum((Y-A*Xtrue).^2)));
supp = find(sum(Xtrue,2));

%% parameter setting for JSpBLRU and BiJSpLRU
% partition strategy for XT
blocknum = 3;
numpat   = blocknum *ones(1, fix(size(Y,2)/blocknum));
numpat(end) = numpat(end) + mod(size(Y,2),blocknum);
if sum(numpat)~= size(Y,2)
    error('block partition does not match!')
end

K0      = length(numpat);  % number of blocks
maxiter = 300;
parameter.verbose = 0;
parameter.K0      = K0;
parameter.MaxIter = maxiter;
parameter.numpat  = numpat;

%% run JSpBLRU with optimal parameters
parameter_jsp        = parameter;
parameter_jsp.gamma  = 0.005;
parameter_jsp.tau    = 5;
parameter_jsp.mu     = 1;
tic
X_jsp   = JSpBLRU(Y,A,parameter_jsp);
cpu_jsp = toc;

SRE_jsp  = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_jsp(:)).^2 ) );
RMSE_jsp = sqrt(mean((X_jsp(:) - Xtrue(:)).^2));

%% run BiJSpBLRU with optimal parameters
parameter_bijsp        = parameter;
parameter_bijsp.gamma  = 0.005;
parameter_bijsp.tau    = 10;
parameter_bijsp.mu     = 0.1;

tic
X_bijsp   = BiJSpLRU(Y,A,parameter_bijsp);
cpu_bijsp = toc;

SRE_bijsp  = 10*log10( sum(Xtrue(:).^2) / sum( (Xtrue(:) - X_bijsp(:)).^2 ) );
RMSE_bijsp = sqrt(mean((X_bijsp(:) - Xtrue(:)).^2));

%% display SRE and RMSE values
clc
disp(['       ', 'JSpBLRU  ', ' BiJSpLRU ']);
fprintf('SRE:  %8.2f %10.2f\n', SRE_jsp, SRE_bijsp)
fprintf('RMSE: %8.4f %10.4f\n', RMSE_jsp, RMSE_bijsp)
fprintf('Time: %8.4f %10.4f\n', cpu_jsp, cpu_bijsp)

%% display estimated abundance maps
Xtrue_im    = reshape(Xtrue', sqrt(size(Y,2)), sqrt(size(Y,2)), size(A,2));
X_jsp_im    = reshape(X_jsp', sqrt(size(Y,2)), sqrt(size(Y,2)), size(A,2));
X_bijsp_im  = reshape(X_bijsp', sqrt(size(Y,2)), sqrt(size(Y,2)),size(A,2));

close all
figure,colormap('jet')
subplot(131),imagesc(Xtrue_im(:,:,supp(8)),[0, 1]);
colorbar;title('True--EM #9');
subplot(132),imagesc(X_jsp_im(:,:,supp(8)),[0, 1]);
colorbar;title('JSpBLRU--EM #9');
subplot(133),imagesc(X_bijsp_im(:,:,supp(8)),[0, 1]);
colorbar;title('BiJSpLRU--EM #9');
